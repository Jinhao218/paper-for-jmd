%% An active learning Kriging-assisted method for reliability-based design optimization under distributional p-box model
%% Jinhao Zhang

clear;clc;
global xmu
ysig1=[0.3,0.4];
ysig2=[0.3,0.4];
xmid1=5;
xmid2=5;
lbx1=0;
lbx2=0;
ubx1=10;
ubx2=10;

options = optimoptions('fmincon','Algorithm','sqp','Display','off');
global mppx1 mppx2 mppx3 fec
fec=0;

[xmu,f]=fmincon(@obj,[xmid1,xmid2],[],[],[],[],[0 0],[10 10],@cons,options);

%%
xd1=[0 0];
xd2=[1 1];
iter=0;
while norm(xd2-xd1)>1e-3
    iter=iter+1
    lb=[-5*ones(1,2),ysig1(1),ysig2(1)];
    ub=[5*ones(1,2),ysig1(2),ysig2(2)];
    u0=(lb+ub)./2;
    options_mpp = optimoptions('fmincon','Algorithm','sqp','Display','off','SpecifyObjectiveGradient',true);%false
    [u1,g1]=fmincon(@cons1,u0,[],[],[],[],lb,ub,@cons_beta,options_mpp);
    [u2,g2]=fmincon(@cons2,u0,[],[],[],[],lb,ub,@cons_beta,options_mpp);
    [u3,g3]=fmincon(@cons3,u0,[],[],[],[],lb,ub,@cons_beta,options_mpp);
    mppux1=u1(:,1:2);
    mppux2=u2(:,1:2);
    mppux3=u3(:,1:2);
    mppx1=mppux1.*u1(:,3:4);
    mppx2=mppux2.*u2(:,3:4);
    mppx3=mppux3.*u2(:,3:4);

    xd1=xmu;
    options_deter = optimoptions('fmincon','Algorithm','sqp','Display','off','SpecifyConstraintGradient',true);
    [xmu,f]=fmincon(@obj,[xmid1,xmid2],[],[],[],[],[0 0],[10 10],@cons_mpp,options_deter);
    xmu
    f
    xd2=xmu;
end





