function [c,ceq,dc,dceq]=cons(Z)
global fec
fec=fec+15;
ysig1=[0.3,0.4];
ysig2=[0.3,0.4];

x(:,1:2)=Z;
mux1=x(:,1);
mux2=x(:,2);
g1=mux1.^2.*mux2./20-1;
g2=(mux1+mux2-5).^2./30+(mux1-mux2-12).^2./120-1;
g3=80./(mux1.^2+8*mux2+5)-1;
c=-[g1,g2,g3];
ceq=[];


[M,N]=size(Z);

for i=1:N
    z_dg1=Z;
    z_dg1(:,i)=z_dg1(:,i)-0.0001;
    x(:,1:2)=z_dg1;
    mux1=x(:,1);
    mux2=x(:,2);
    dgL1=mux1.^2.*mux2./20-1;
    dgL2=(mux1+mux2-5).^2./30+(mux1-mux2-12).^2./120-1;
    dgL3=80./(mux1.^2+8*mux2+5)-1;
    
    z_dg2=Z;
    z_dg2(:,i)=z_dg2(:,i)+0.0001;
    x(:,1:2)=z_dg2;
    mux1=x(:,1);
    mux2=x(:,2);
    dgU1=mux1.^2.*mux2./20-1;
    dgU2=(mux1+mux2-5).^2./30+(mux1-mux2-12).^2./120-1;
    dgU3=80./(mux1.^2+8*mux2+5)-1;
    
    dc(i,:)=-[(dgU1-dgL1)/0.0002,(dgU2-dgL2)/0.0002,(dgU3-dgL3)/0.0002];
end

dceq=[];
end

