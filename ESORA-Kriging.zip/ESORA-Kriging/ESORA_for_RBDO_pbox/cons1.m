function [g,dg]=cons1(Z)
global xmu fec
fec=fec+5;
ysig1=[0.3,0.4];
ysig2=[0.3,0.4];

mu=[xmu];
sigma=[Z(:,3:4)];
x=Z(:,1:2).*sigma+mu;

mux1=x(:,1);
mux2=x(:,2);
g=mux1.^2.*mux2./20-1;

[M,N]=size(Z);
for i=1:N
    z_dg1=Z;
    z_dg1(:,i)=z_dg1(:,i)-0.0001;
    mu=[xmu];
    sigma=[z_dg1(:,3:4)];
    x=z_dg1(:,1:2).*sigma+mu;
    mux1=x(:,1);
    mux2=x(:,2);
    g1=mux1.^2.*mux2./20-1;

    z_dg2=Z;
    z_dg2(:,i)=z_dg2(:,i)+0.0001;
    mu=[xmu];
    sigma=[z_dg2(:,3:4)];
    x=z_dg2(:,1:2).*sigma+mu;
    mux1=x(:,1);
    mux2=x(:,2);
    g2=mux1.^2.*mux2./20-1;
    
    dg(i,1)=(g2-g1)/0.0002;
end
end
