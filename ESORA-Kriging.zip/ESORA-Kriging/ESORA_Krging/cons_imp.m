function [c,ceq,dc,dceq]=cons_imp(Z)
global model_cons1 model_cons2 model_cons3
ysig1=[0.3,0.4];
ysig2=[0.3,0.4];

x(:,1:2)=Z;
mux1=x(:,1);
mux2=x(:,2);
g1=predictor([mux1,mux2],model_cons1);
g2=predictor([mux1,mux2],model_cons2);
g3=predictor([mux1,mux2],model_cons3);
c=-[g1,g2,g3];
ceq=[];


[M,N]=size(Z);

for i=1:N
    z_dg1=Z;
    z_dg1(:,i)=z_dg1(:,i)-0.0001;
    x(:,1:2)=z_dg1;
    mux1=x(:,1);
    mux2=x(:,2);
    dgL1=predictor([mux1,mux2],model_cons1);
    dgL2=predictor([mux1,mux2],model_cons2);
    dgL3=predictor([mux1,mux2],model_cons3);
    
    z_dg2=Z;
    z_dg2(:,i)=z_dg2(:,i)+0.0001;
    x(:,1:2)=z_dg2;
    mux1=x(:,1);
    mux2=x(:,2);
    dgU1=predictor([mux1,mux2],model_cons1);
    dgU2=predictor([mux1,mux2],model_cons2);
    dgU3=predictor([mux1,mux2],model_cons3);
    
    dc(i,:)=-[(dgU1-dgL1)/0.0002,(dgU2-dgL2)/0.0002,(dgU3-dgL3)/0.0002];
end

dceq=[];
end

