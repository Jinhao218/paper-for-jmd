function [cons3] = cons_exp3(x)

cons3=80./(x(:,1).^2+8*x(:,2)+5)-1;
end

