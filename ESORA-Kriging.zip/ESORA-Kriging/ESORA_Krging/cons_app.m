function [cons,ceq,c_g,ceq_g] = cons_app(x)

global det
global beta
global ux
global model_cons1 model_cons2 model_cons3

[m,n]=size(ux);
for i=1:m
    model=eval(strcat('model_cons',num2str(i)));
    mpp=x+repmat(det,size(x,1),1).*repmat(ux(i,:),size(x,1),1);
    cons(i)=predictor(mpp,model);
    [~,df_cons(i,:),~]=predictor(mpp,model);
end
cons=-cons;
ceq=[];
c_g=-df_cons';
ceq_g=[];

end

