function [inf_mod_cons1,inf_mod_cons2,inf_mod_cons3]=update_cons(solution,inf_mod_cons1,inf_mod_cons2,inf_mod_cons3,parameter)

[inf_mod_cons1,is_update(1,:)]=add_point_cons(1,solution,inf_mod_cons1,parameter);
[inf_mod_cons2,is_update(2,:)]=add_point_cons(2,solution,inf_mod_cons2,parameter);
[inf_mod_cons3,is_update(3,:)]=add_point_cons(3,solution,inf_mod_cons3,parameter);

trainx1=inf_mod_cons1.train_x(end,:);
trainx2=inf_mod_cons2.train_x(end,:);
trainx3=inf_mod_cons3.train_x(end,:);


for i=1:3
    if is_update(i,:)==1
        for j=1:3
            if j~=i
                cons=str2func(strcat(['cons_exp',num2str(j)]));
                new_x=eval(strcat(['trainx',num2str(i)]));
                new_y=cons(new_x);
                eval(strcat(['train_x_cons=','inf_mod_cons',num2str(j),'.train_x;']));
                eval(strcat(['train_y_cons=','inf_mod_cons',num2str(j),'.train_y;']));
                train_x_cons=[train_x_cons;new_x];
                train_y_cons=[train_y_cons;new_y];
                L=2;
                theta = 10*ones(1,L);
                lob = (1e-2)*ones(1,L);
                upb = 30*ones(1,L);
                [model_cons,~]=dacefit(train_x_cons,train_y_cons,@regpoly1,@corrgauss,theta,lob,upb);%repoly2��Ҫ�ܶ�㽨ģ
                eval(strcat(['inf_mod_cons',num2str(j),'.model=','model_cons;']));
                eval(strcat(['inf_mod_cons',num2str(j),'.train_x=','train_x_cons;']));
                eval(strcat(['inf_mod_cons',num2str(j),'.train_y=','train_y_cons;']));
            end
        end
    end
end
end


