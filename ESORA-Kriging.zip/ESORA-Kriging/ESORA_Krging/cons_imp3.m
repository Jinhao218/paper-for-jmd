function [g,dg]=cons3_imp(Z)
global xmu model_cons1 model_cons2 model_cons3
ysig1=[0.3,0.4];
ysig2=[0.3,0.4];

mu=[xmu];
sigma=[Z(:,3:4)];
x=Z(:,1:2).*sigma+mu;

mux1=x(:,1);
mux2=x(:,2);
g=predictor([mux1,mux2],model_cons3);

[M,N]=size(Z);
for i=1:N
    z_dg1=Z;
    z_dg1(:,i)=z_dg1(:,i)-0.0001;
    mu=[xmu];
    sigma=[z_dg1(:,3:4)];
    x=z_dg1(:,1:2).*sigma+mu;
    mux1=x(:,1);
    mux2=x(:,2);
    g1=predictor([mux1,mux2],model_cons3);

    z_dg2=Z;
    z_dg2(:,i)=z_dg2(:,i)+0.0001;
    mu=[xmu];
    sigma=[z_dg2(:,3:4)];
    x=z_dg2(:,1:2).*sigma+mu;
    mux1=x(:,1);
    mux2=x(:,2);
    g2=predictor([mux1,mux2],model_cons3);
    
    dg(i,1)=(g2-g1)/0.0002;
end
end