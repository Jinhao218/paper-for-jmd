function [model,sam_x,sam_y] =app_cons2(parameter)

num_var=parameter.num_var;
num_doe_cons2=parameter.num_doe_cons2;
lb=parameter.lb;
ub=parameter.ub;
LHS=lhsdesign(num_doe_cons2,num_var);
lb =repmat(lb,num_doe_cons2,1);
ub=repmat(ub,num_doe_cons2,1);

sam_x=[0 0;
    0 5;
    0 10;
    5 0;
    5 5;
    5 10;
    10 0;
    10 5;
    10 10];
sam_y=cons_exp2(sam_x);

 L=num_var;
 theta = 10*ones(1,L);
 lob = (1e-2)*ones(1,L);
 upb = 30*ones(1,L);
[model,~]=dacefit(sam_x,sam_y,@regpoly1,@corrgauss,theta,lob,upb);
end

