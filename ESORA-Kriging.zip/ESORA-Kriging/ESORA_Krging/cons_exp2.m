function [cons2] = cons_exp2(x)

cons2=(x(:,1)+x(:,2)-5).^2./30+(x(:,1)-x(:,2)-12).^2./120-1;
end

