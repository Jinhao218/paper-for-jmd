function f=obj(x)
mux1=x(:,1);
mux2=x(:,2);
f=-mux1+mux2;
end