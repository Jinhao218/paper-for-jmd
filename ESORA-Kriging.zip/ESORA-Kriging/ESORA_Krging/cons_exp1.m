function [cons1] = cons_exp1(x)

cons1=x(:,1).^2.*x(:,2)./20-1;
end

