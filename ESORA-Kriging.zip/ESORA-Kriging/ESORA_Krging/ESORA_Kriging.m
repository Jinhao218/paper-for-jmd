%% An active learning Kriging-assisted method for reliability-based design optimization under distributional p-box model
%% Jinhao Zhang

%% Please add the 'dace' file into the MATLAB path before performing this code !!

close all;
clear;
clc;


rand('seed',1)%For repeatable experiment
randn('seed',1)%For repeatable experiment


%% 
global beta
beta=[3,3,3];%
ysig1=[0.3,0.4];
ysig2=[0.3,0.4];
xmid1=5;
xmid2=5;
lbx=[0 0];
ubx=[10 10];

num_var=2;
num_cons=3;
parameter.beta=beta;
parameter.num_var=num_var;
parameter.num_cons=num_cons;
parameter.lb=lbx;
parameter.ub=ubx;

%% 
global fec
fec=0;

%% 
global model_cons1 model_cons2 model_cons3
num_doe_cons1=9;
num_doe_cons2=9;
num_doe_cons3=9;
parameter.num_doe_cons1=num_doe_cons1;
parameter.num_doe_cons2=num_doe_cons2;
parameter.num_doe_cons3=num_doe_cons3;
[model_cons1,train_x_cons1,train_y_cons1] = app_cons1(parameter);
parameter.train_x_cons1=train_x_cons1;
[model_cons2,train_x_cons2,train_y_cons2] = app_cons2(parameter);
[model_cons3,train_x_cons3,train_y_cons3] = app_cons3(parameter);

inf_mod_cons1.model=model_cons1;
inf_mod_cons1.train_x=train_x_cons1;
inf_mod_cons1.train_y=train_y_cons1;
inf_mod_cons2.model=model_cons2;
inf_mod_cons2.train_x=train_x_cons2;
inf_mod_cons2.train_y=train_y_cons2;
inf_mod_cons3.model=model_cons3;
inf_mod_cons3.train_x=train_x_cons3;
inf_mod_cons3.train_y=train_y_cons3;

inf_mod_cons1.model_error=-1;
inf_mod_cons2.model_error=-1;
inf_mod_cons3.model_error=-1;

%% 
options = optimoptions('fmincon','Algorithm','sqp','Display','off','SpecifyConstraintGradient',true);

%% 
global xmu mppx1 mppx2 mppx3
[xmu,f]=fmincon(@obj,[xmid1,xmid2],[],[],[],[],lbx,ubx,@cons_imp,options);


%% 
iter=1
solution(iter,:).ux=zeros(num_cons,num_var);
solution(iter,:).fec=fec;
solution(iter,:).xmu=xmu;
solution(iter,:).f=f;

%% 
xd1=[0 0];
xd2=[1 1];
k=0;
while norm(xd2-xd1)>1e-6&&k<20
    k=k+1;
    lb=[-5*ones(1,2),ysig1(1),ysig2(1)];
    ub=[5*ones(1,2),ysig1(2),ysig2(2)];
    u0=(lb+ub)./2;
    
    options_mpp = optimoptions('fmincon','Algorithm','sqp','Display','off','SpecifyObjectiveGradient',true);

    [u1,g1]=fmincon(@cons_imp1,u0,[],[],[],[],lb,ub,@cons_beta,options_mpp);
    [u2,g2]=fmincon(@cons_imp2,u0,[],[],[],[],lb,ub,@cons_beta,options_mpp);
    [u3,g3]=fmincon(@cons_imp3,u0,[],[],[],[],lb,ub,@cons_beta,options_mpp);
    mppux1=u1(:,1:2);
    mppux2=u2(:,1:2);
    mppux3=u3(:,1:2);
    mppx1=mppux1.*u1(:,3:4);
    mppx2=mppux2.*u2(:,3:4);
    mppx3=mppux3.*u2(:,3:4);
    xd1=xmu;
    options_deter = optimoptions('fmincon','Algorithm','sqp','Display','off','SpecifyConstraintGradient',true);
    [xmu,f]=fmincon(@obj,[xmid1,xmid2],[],[],[],[],lbx,ubx,@cons_mpp,options_deter);
    xd2=xmu;
end

xmu
f

parameter.det1=u1(:,3:4);
parameter.det2=u2(:,3:4);
parameter.det3=u3(:,3:4);

iter=iter+1
solution(iter,:).ux=[u1(:,1:2);u2(:,1:2);u3(:,1:2)];
solution(iter,:).xmu=xmu;
solution(iter,:).f=f;

%% 
erro_mux=1;
erro_ux=1;

while erro_mux>1e-3

    proc_xmu=xmu;
    % 
    [inf_mod_cons1,inf_mod_cons2,inf_mod_cons3]=update_cons(solution,...
        inf_mod_cons1,inf_mod_cons2,inf_mod_cons3,parameter);
    
    model_cons1=inf_mod_cons1.model;
    model_cons2=inf_mod_cons2.model;
    model_cons3=inf_mod_cons3.model;
   
    [xmu,f]=fmincon(@obj,[xmid1,xmid2],[],[],[],[],lbx,ubx,@cons_imp,options);
    xd1=[0 0];
    xd2=[1 1];
    k=0;
    while norm(xd2-xd1)>1e-3&&k<20
        k=k+1;
        lb=[-5*ones(1,2),ysig1(1),ysig2(1)];
        ub=[5*ones(1,2),ysig1(2),ysig2(2)];
        u0=(lb+ub)./2;
        
        options_mpp = optimoptions('fmincon','Algorithm','sqp','Display','off','SpecifyObjectiveGradient',true);
        
        [u1,g1]=fmincon(@cons_imp1,u0,[],[],[],[],lb,ub,@cons_beta,options_mpp);
        [u2,g2]=fmincon(@cons_imp2,u0,[],[],[],[],lb,ub,@cons_beta,options_mpp);
        [u3,g3]=fmincon(@cons_imp3,u0,[],[],[],[],lb,ub,@cons_beta,options_mpp);
        mppux1=u1(:,1:2);
        mppux2=u2(:,1:2);
        mppux3=u3(:,1:2);
        mppx1=mppux1.*u1(:,3:4);
        mppx2=mppux2.*u2(:,3:4);
        mppx3=mppux3.*u2(:,3:4);
        xd1=xmu;
        options_deter = optimoptions('fmincon','Algorithm','sqp','Display','off','SpecifyConstraintGradient',true);
        [xmu,f]=fmincon(@obj,[xmid1,xmid2],[],[],[],[],lbx,ubx,@cons_mpp,options_deter);
        xd2=xmu;
    end
    xmu
    f
    iter=iter+1
    solution(iter,:).ux=[u1(:,1:2);u2(:,1:2);u3(:,1:2)];
    solution(iter,:).xmu=xmu;
    solution(iter,:).f=f;
    
	parameter.det1=u1(:,3:4);
    parameter.det2=u2(:,3:4);
    parameter.det3=u3(:,3:4);
	
    erro_mux=norm((proc_xmu-xmu))./norm((xmu+1e-16));
end

    