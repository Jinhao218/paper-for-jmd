function [c,ceq]=cons_beta(Z)
beta=3;
ceq=norm(Z(:,1:2))-beta;
c=[];
end