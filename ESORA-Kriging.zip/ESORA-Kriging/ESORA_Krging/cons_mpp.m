function [c,ceq,dc,dceq]=cons_mpp(x)
global mppx1 mppx2 mppx3 model_cons1 model_cons2 model_cons3
g1=cons1_mpp(x);
g2=cons2_mpp(x);
g3=cons3_mpp(x);
c=-[g1,g2,g3];
ceq=[];

[M,N]=size(x);
for i=1:N
    x_dg1=x;
    x_dg1(:,i)=x_dg1(:,i)-0.0001;
    dgL1=cons1_mpp(x_dg1);
    dgL2=cons2_mpp(x_dg1);
    dgL3=cons3_mpp(x_dg1);

    x_dg2=x;
    x_dg2(:,i)=x_dg2(:,i)+0.0001;
    dgU1=cons1_mpp(x_dg2);
    dgU2=cons2_mpp(x_dg2);
    dgU3=cons3_mpp(x_dg2);
    
    dc(i,:)=-[(dgU1-dgL1)/0.0002,(dgU2-dgL2)/0.0002,(dgU3-dgL3)/0.0002];
end
dceq=[];
end

function g1=cons1_mpp(x)
global mppx1 mppx2 mppx3 model_cons1 model_cons2 model_cons3
x(:,1:2)=x(:,1:2)+mppx1;
mux1=x(:,1);
mux2=x(:,2);
g1=predictor([mux1,mux2],model_cons1);
end

function g2=cons2_mpp(x)
global mppx1 mppx2 mppx3 model_cons1 model_cons2 model_cons3
x(:,1:2)=x(:,1:2)+mppx2;
mux1=x(:,1);
mux2=x(:,2);
g2=predictor([mux1,mux2],model_cons2);
end

function g3=cons3_mpp(x)
global mppx1 mppx2 mppx3 model_cons1 model_cons2 model_cons3
x(:,1:2)=x(:,1:2)+mppx3;
mux1=x(:,1);
mux2=x(:,2);
g3=predictor([mux1,mux2],model_cons3);
end