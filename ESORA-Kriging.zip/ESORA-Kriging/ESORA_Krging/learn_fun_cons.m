function [min_lf_mpp,id_lf_mpp]=learn_fun_cons(id,mux,ux,num_lf,sam_mpp,inf_mod_cons,parameter)
lb=parameter.lb;
ub=parameter.ub;
beta=parameter.beta;
num_var=parameter.num_var;
det=eval(strcat(['parameter.det',num2str(id)]));

ux=ux(id,:);

train_x_cons=inf_mod_cons.train_x;
model_cons=inf_mod_cons.model;

mpp=mux+det.*ux;
[mpp_y,~,mpp_mse]=predictor(mpp,model_cons);
mpp_u=(abs(mpp_y)./mpp_mse.^0.5);
if mpp_u<2

    [y_mpp,mse_mpp]=predictor(sam_mpp,model_cons);
    u_mpp=(abs(y_mpp)./mse_mpp.^0.5);

    s_mpp=sam_mpp-repmat(mux,num_lf,1);
    s_mpp=s_mpp./repmat(det,num_lf,1);
    beta_mpp=sum(s_mpp.^2,2).^0.5;
    exp_mpp=exp((beta_mpp-beta(id)).^2);
    

    for i=1:num_lf
        num_train=size(train_x_cons,1);
        dist_mpp=sqrt(sum((repmat(sam_mpp(i,:),num_train,1)-train_x_cons).^2,2));
        dist_min_mpp(i,:)=min(dist_mpp);
    end

    dist_min_mpp=norm(ub-lb)./dist_min_mpp;

    lf_mpp=u_mpp.*exp_mpp.*dist_min_mpp;
    
    for j=1:num_var
        if j==1
            id=(sam_mpp(:,j)<lb(j))|(sam_mpp(:,j)>ub(j));
        else
            id=id|(sam_mpp(:,j)<lb(j))|(sam_mpp(:,j)>ub(j));
        end
    end
    
    lf_mpp(id,:)=inf;

    [min_lf_mpp,id_lf_mpp]=min(lf_mpp);
    
else
    min_lf_mpp=-1;
    id_lf_mpp=0;
end

    
    