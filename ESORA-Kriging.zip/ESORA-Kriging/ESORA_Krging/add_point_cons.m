function [inf_mod_cons,is_update]=add_point_cons(id_cons,solution,inf_mod_cons,parameter)
xmu=solution(end).xmu;
ux=solution(end).ux;

train_x_cons=inf_mod_cons.train_x;
train_y_cons=inf_mod_cons.train_y;
model_cons=inf_mod_cons.model;
model_error=inf_mod_cons. model_error;

lb=parameter.lb;
ub=parameter.ub;
beta=parameter.beta;
num_var=parameter.num_var;
det=eval(strcat(['parameter.det',num2str(id_cons)]));

%% 
num_lf=10000;
rand_rho=rand(num_lf,1);
rand_alpha1=2*pi.*rand(num_lf,1);

sam_delta1=rand_rho.*cos(rand_alpha1);
sam_delta2=rand_rho.*sin(rand_alpha1);

sam_mpp=beta(1).*repmat(det,num_lf,1).*[sam_delta1,sam_delta2]+repmat(xmu,num_lf,1)+repmat(det,num_lf,1).*repmat(ux(id_cons,:),num_lf,1);

%% 
L=num_var;
theta = 10*ones(1,L);
lob = (1e-2)*ones(1,L);
upb = 30*ones(1,L);

% 
cons=str2func(strcat(['cons_exp',num2str(id_cons)]));


if size(solution,1)>2
    error_dp=norm((solution(end-1).xmu-solution(end).xmu))./norm((solution(end).xmu+1e-16));
else
    error_dp=-1;
end

is_update=0;
if (model_error<0||model_error>1e-6)
    [min_lf_mpp,id_lf_mpp]=learn_fun_cons(id_cons,xmu,ux,num_lf,sam_mpp,inf_mod_cons,parameter); 
    if min_lf_mpp>0
        is_update=1;
        new_x=sam_mpp(id_lf_mpp,:);
        new_y=cons(new_x);
        pre_y=predictor(new_x,model_cons);
        model_error=norm(new_y-pre_y)/(max(train_y_cons)-min(train_y_cons));
        train_x_cons=[train_x_cons;new_x];
        train_y_cons=[train_y_cons;new_y];
        L=num_var;
        theta = 10*ones(1,L);
        lob = (1e-2)*ones(1,L);
        upb = 30*ones(1,L);
        [model_cons,~]=dacefit(train_x_cons,train_y_cons,@regpoly1,@corrgauss,theta,lob,upb);
    end 
end

inf_mod_cons.model=model_cons;
inf_mod_cons.train_x=train_x_cons;
inf_mod_cons.train_y=train_y_cons;
inf_mod_cons.model_error=model_error;
end


